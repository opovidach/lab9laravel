Simple Laravel imageboard
No JavaScript

![Screenshot](docs/images/preview.png)
